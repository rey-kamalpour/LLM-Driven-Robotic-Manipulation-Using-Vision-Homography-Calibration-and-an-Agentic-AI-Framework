# Robot_Tools/Robot_Motion_Tools.py
import cv2
from pydobot.dobot import MODE_PTP
import pydobot
import time
import numpy as np
import os
import json
from google.genai import types
from config import  M,default_port


# =========================================================
# GLOBAL STATE
# =========================================================
device = None          # single global Dobot handle
affine_matrix = M      # now supports full 3x3 homography
default_port = default_port


# =========================================================
# HELPER: ensure device is connected
# =========================================================
def _ensure_device(port=default_port):
    global device
    if device is None:
        device = pydobot.Dobot(port)
    return device


# =========================================================
# ROBOT FUNCTION 1: get_dobot_device
# =========================================================
def get_dobot_device(port=default_port):
    """
    Connect to the Dobot and store the device globally.
    """
    global device
    try:
        device = pydobot.Dobot(port)
        return f"Connected to Dobot on port {port}"
    except Exception as e:
        return f"Error connecting to Dobot on port {port}: {e}"


schema_get_dobot_device = types.FunctionDeclaration(
    name="get_dobot_device",
    description="Connects to the Dobot robot on the specified serial/USB port.",
    parameters=types.Schema(
        type=types.Type.OBJECT,
        properties={"port": types.Schema(type=types.Type.STRING)},
    ),
)


def device_close():
    global device
    if device:
        device.close()


# =========================================================
# ROBOT FUNCTION 2: move_to_home
# =========================================================
def move_to_home():
    try:
        dev = _ensure_device()
        dev.home()
        time.sleep(2)
        return "Robot homed"
    except Exception as e:
        return f"Error homing robot: {e}"


schema_move_to_home = types.FunctionDeclaration(
    name="move_to_home",
    description="Homes the Dobot robot.",
    parameters=types.Schema(type=types.Type.OBJECT),
)


# =========================================================
# ROBOT FUNCTION 3: move_to_specific_position
# =========================================================
def move_to_specific_position(x: float, y: float, z: float, r: float = 0.0):
    try:
        dev = _ensure_device()
        dev.speed(50, 50)
        dev.move_to(mode=int(MODE_PTP.MOVJ_XYZ), x=x, y=y, z=z, r=r)
        time.sleep(2)
        return f"Moved to x={x}, y={y}, z={z}, r={r}"
    except Exception as e:
        return f"Error in move_to_specific_position: {e}"


schema_move_to_specific_position = types.FunctionDeclaration(
    name="move_to_specific_position",
    description="Moves the robot to a specific pose.",
    parameters=types.Schema(
        type=types.Type.OBJECT,
        properties={
            "x": types.Schema(type=types.Type.NUMBER),
            "y": types.Schema(type=types.Type.NUMBER),
            "z": types.Schema(type=types.Type.NUMBER),
            "r": types.Schema(type=types.Type.NUMBER),
        },
    ),
)


# =========================================================
# ROBOT FUNCTION 4: get_current_pose
# =========================================================
def get_current_pose():
    try:
        dev = _ensure_device()
        time.sleep(0.5)
        pose, joint = dev.get_pose()
        return {"pose": list(pose), "joint": list(joint)}
    except Exception as e:
        return f"Error in get_current_pose: {e}"


schema_get_current_pose = types.FunctionDeclaration(
    name="get_current_pose",
    description="Reads the robot's current pose and joints.",
    parameters=types.Schema(type=types.Type.OBJECT),
)


# =========================================================
# ROBOT FUNCTION 5: suction on/off
# =========================================================
def suction_on():
    try:
        dev = _ensure_device()
        dev.suck(True)
        return "Suction ON"
    except Exception as e:
        return f"Error turning suction ON: {e}"


def suction_off():
    try:
        dev = _ensure_device()
        dev.suck(False)
        return "Suction OFF"
    except Exception as e:
        return f"Error turning suction OFF: {e}"


schema_suction_on = types.FunctionDeclaration(
    name="suction_on",
    description="Turns suction ON.",
    parameters=types.Schema(type=types.Type.OBJECT),
)

schema_suction_off = types.FunctionDeclaration(
    name="suction_off",
    description="Turns suction OFF.",
    parameters=types.Schema(type=types.Type.OBJECT),
)


# =========================================================
# PIXEL → ROBOT TRANSFORM (Affine or Homography)
# =========================================================
def apply_affine(M, u, v):
       
        p = np.array([[[u, v]]], dtype=float)
       
        p_r = cv2.perspectiveTransform(p, M)[0][0]
        
        x=p_r[0]
        y=p_r[1]
        print(M)
        print("x = ",u,"Y=",v,"---->","Rx=",x,"Ry=",y)
        return float(x), float(y)
# =========================================================
def apply_affine1(M, u, v):
    """
    Converts pixel (u,v) to robot (x,y) using a FULL 3x3 matrix.
    Supports homography and affine.
    """
    uv1 = np.array([u, v, 1.0], dtype=np.float64)
    XYZ = M @ uv1
    w = XYZ[2]

    if abs(w) < 1e-9:
        raise ValueError("Homography produced w=0, invalid transformation.")

    x = XYZ[0] / w
    y = XYZ[1] / w

    return float(x), float(y)


def set_affine_matrix(matrix_flat):
    global affine_matrix
    try:
        arr = np.array(matrix_flat, dtype=np.float64).reshape(3, 3)
        affine_matrix = arr
        return "Affine/Homography matrix updated"
    except Exception as e:
        return f"Error setting affine matrix: {e}"


schema_set_affine_matrix = types.FunctionDeclaration(
    name="set_affine_matrix",
    description="Sets the global 3x3 affine/homography matrix.",
    parameters=types.Schema(
        type=types.Type.OBJECT,
        properties={
            "matrix_flat": types.Schema(
                type=types.Type.ARRAY,
                items=types.Schema(type=types.Type.NUMBER),
            ),
        },
    ),
)


# =========================================================
# move_robot_point_above
# =========================================================
def move_robot_point_above(u: float, v: float, z_above: float = -30.0):
    global affine_matrix
    try:
        dev = _ensure_device()

        Xa, Ya = apply_affine(affine_matrix, u, v)
        print(f"Pixel({u},{v}) → Robot({Xa:.2f},{Ya:.2f})")

        dev.speed(50, 50)
        dev.move_to(mode=int(MODE_PTP.MOVJ_XYZ), x=Xa, y=Ya, z=z_above, r=0.0)
        time.sleep(1)

        return {"x": Xa, "y": Ya, "z": z_above, "message": "Moved above pixel"}
    except Exception as e:
        return f"Error in move_robot_point_above: {e}"


schema_move_robot_point_above = types.FunctionDeclaration(
    name="move_robot_point_above",
    description="Moves robot above the pixel using homography.",
    parameters=types.Schema(
        type=types.Type.OBJECT,
        properties={
            "u": types.Schema(type=types.Type.NUMBER),
            "v": types.Schema(type=types.Type.NUMBER),
            "z_above": types.Schema(type=types.Type.NUMBER),
        },
    ),
)


# =========================================================
# move_robot_point_block
# =========================================================
def move_robot_point_block(u: float, v: float, block_height: float = -30.0):
    global affine_matrix
    try:
        dev = _ensure_device()

        Xa, Ya = apply_affine(affine_matrix, u, v)
        print(f"Pixel({u},{v}) → Robot({Xa:.2f},{Ya:.2f})")

        dev.speed(50, 50)
        dev.move_to(mode=int(MODE_PTP.MOVJ_XYZ), x=Xa, y=Ya, z=block_height, r=0.0)
        time.sleep(1)

        return {"x": Xa, "y": Ya, "z": block_height, "message": "Moved to block"}
    except Exception as e:
        return f"Error in move_robot_point_block: {e}"


schema_move_robot_point_block = types.FunctionDeclaration(
    name="move_robot_point_block",
    description="Moves robot to block height at pixel.",
    parameters=types.Schema(
        type=types.Type.OBJECT,
        properties={
            "u": types.Schema(type=types.Type.NUMBER),
            "v": types.Schema(type=types.Type.NUMBER),
            "block_height": types.Schema(type=types.Type.NUMBER),
        },
    ),
)


# =========================================================
# SCENE MEMORY WRITER
# =========================================================
def update_scene_memory(
    detection_json_path: str,
    scene_memory_path: str = "scene_memory.json",
    default_z: float = -40.0,
):
    try:
        if not os.path.exists(detection_json_path):
            return f"Detection file not found: {detection_json_path}"

        with open(detection_json_path, "r") as f:
            detections = json.load(f)

        scene_memory = []
        for item in detections:
            scene_memory.append({
                "label": item.get("label"),
                "x": item.get("x"),
                "y": item.get("y"),
                "z": default_z,
            })

        with open(scene_memory_path, "w") as f:
            json.dump(scene_memory, f, indent=2)

        return f"Scene memory updated: {scene_memory_path}"
    except Exception as e:
        return f"Error in update_scene_memory: {e}"


schema_update_scene_memory = types.FunctionDeclaration(
    name="update_scene_memory",
    parameters=types.Schema(
        type=types.Type.OBJECT,
        properties={
            "detection_json_path": types.Schema(type=types.Type.STRING),
            "scene_memory_path": types.Schema(type=types.Type.STRING),
            "default_z": types.Schema(type=types.Type.NUMBER),
        },
    ),
)


# =========================================================
# MAIN (Optional test)
# =========================================================
if __name__ == "__main__":
    print(get_dobot_device())
    print(move_to_home())
